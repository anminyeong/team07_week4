package com.your.dream.web;

public class Dream {

	public Dream(int ageToBeTrue) {
	}

	public boolean comeTrue() {
		return false;
	}

}
